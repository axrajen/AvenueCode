package com.pom.common;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.pom.common.LaunchApp;


public class ProductPage {
	
	public static LaunchApp MywebDriver;
	private static WebDriverWait wait;
	
	public static List<WebElement> MyProductQuantity(WebDriver Driver){
		int iCount = 0;
		List <WebElement> MyProductWeblement = new ArrayList<WebElement>();
		iCount = MywebDriver.myDriver.findElements(By.xpath(".//*[@class='shopping-items']/div")).size();
	  System.out.println("icount is "+iCount);
		for(int i=0;i<iCount;i++){
		   MyProductWeblement.add(MywebDriver.myDriver.findElement(By.xpath(".//*[@id='updates["+i+"].quantity']")));
	   }
		return MyProductWeblement;
	}
	
	public static void NavigateToProdPage(String mainNav,String subNav){
		Actions myAction = new Actions(MywebDriver.myDriver);
		WebElement MyElement = MywebDriver.myDriver.findElement(By.linkText(mainNav));
		myAction.moveToElement(MyElement).build().perform();
		wait = new WebDriverWait(MywebDriver.myDriver, 5);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(subNav)));  
		MywebDriver.myDriver.findElement(By.linkText(subNav)).click();
	}
	
	public static String clickResultProduct(int prdNum){
		wait = new WebDriverWait(MywebDriver.myDriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='subCatListContainer']/ul/li["+prdNum+"]/a/span")));
		String productName = MywebDriver.myDriver.findElement(By.xpath(".//*[@id='subCatListContainer']/ul/li["+prdNum+"]/a/span")).getText();
		MywebDriver.myDriver.findElement(By.xpath(".//*[@id='subCatListContainer']/ul/li["+prdNum+"]/a/span")).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@class='add-to-basket']")));
		return productName;
	}
	public static void AddShipCart(){
		wait = new WebDriverWait(MywebDriver.myDriver, 30);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@class='btn btn_addtobasket btn_addtobasket_add']")));
		MywebDriver.myDriver.findElement(By.xpath("//*[@class='btn btn_addtobasket btn_addtobasket_add']")).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("racOverlay")));
		MywebDriver.myDriver.findElement(By.id("anchor-btn-checkout")).click();

	}
	
	public static String SearchProduct(String value){
		MywebDriver.myDriver.findElement(By.id("search-field")).sendKeys(value);
		MywebDriver.myDriver.findElement(By.id("btnSearch")).click();
		wait = new WebDriverWait(MywebDriver.myDriver, 60);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='results-summary']/h2")));
		String searchValue = MywebDriver.myDriver.findElement(By.xpath(".//*[@id='results-summary']/h2")).getText();
		return searchValue;
	}
	
	public static List<String> clickOnSearchProductImg(int num)  {
		List <String> myProductList = new ArrayList<String>();		
		Actions myAction = new Actions(MywebDriver.myDriver);
		wait = new WebDriverWait(MywebDriver.myDriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='content']/div[2]/ul/li["+num+"]/div/a[1]/span/img")));
		WebElement myProdImage = MywebDriver.myDriver.findElement(By.xpath(".//*[@id='content']/div[2]/ul/li["+num+"]/div/a[1]/span/img"));
		WebElement ProdName = MywebDriver.myDriver.findElement(By.xpath(".//*[@id='content']/div[2]/ul/li[1]/a/span"));
		String myProductName = ProdName.getText();
		WebElement productPrice = MywebDriver.myDriver.findElement(By.xpath(".//*[@id='content']/div[2]/ul/li["+num+"]/span/span[1]/span/span[2]"));
		String myProdPrice = productPrice.getText();
		myAction.moveToElement(myProdImage).build().perform();
		myProductList.add(myProductName);
		myProductList.add(myProdPrice);
		//MywebDriver.myDriver.findElement(By.xpath(".//*[@id='content']/div[2]/ul/li["+num+"]/div/a[1]/span/img")).click();
		//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@class='add-to-basket']")));
		return myProductList;
	
	}

}
