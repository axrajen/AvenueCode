package com.pom.common;
import com.pom.common.LaunchApp;

import org.openqa.selenium.*;

 
public class LoginPage {
 
        private static WebElement myLoginPageElement = null;
        public static LaunchApp myWebDriver;
       
    public static WebElement userEmailId(WebDriver driver){
 
         myLoginPageElement = driver.findElement(By.id("login-email"));
 
         return myLoginPageElement;
 
         }
 
     public static WebElement userPassword(WebDriver driver){
 
         myLoginPageElement = driver.findElement(By.id("login-password"));
 
         return myLoginPageElement;
 
         }
 
     public static WebElement signInButton(WebDriver driver){
 
         myLoginPageElement = driver.findElement(By.id("btn-sign-in"));
 
         return myLoginPageElement;
 
         }
     
     public static WebElement singnOffButton(WebDriver driver){
    	 myLoginPageElement = driver.findElement(By.xpath(".//*[@id='member-greeting']/a"));
    	 return myLoginPageElement;
     }
     public static void userLogin(){
 		LoginPage.userEmailId(myWebDriver.myDriver).sendKeys(LaunchApp.userName);
 		LoginPage.userPassword(myWebDriver.myDriver).sendKeys(LaunchApp.password);
 		LoginPage.signInButton(myWebDriver.myDriver).click();
 		LaunchApp.waitToPageLoad(40,By.xpath(".//*[@id='member-greeting']/a"));
 		System.out.println("Login Successfull");
     }
 
}