package com.pom.common;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import net.sourceforge.htmlunit.corejs.javascript.tools.shell.QuitAction;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import com.google.common.base.Function;

import java.io.File;
public class LaunchApp {
	public static String url,myBrowser,userName, password;
	
	public static WebDriver myDriver;
	public static void OpenApp(){
		try {
			File configXml = new File("src\\main\\resources\\Config.xml");
			DocumentBuilderFactory buildFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docbuilder = buildFactory.newDocumentBuilder();
			Document fileToParse = docbuilder.parse(configXml);
			fileToParse.getDocumentElement().normalize();
			 
			System.out.println("Root :" + fileToParse.getDocumentElement().getNodeName());
			NodeList myNode = fileToParse.getElementsByTagName("environment");
			for (int nodeLen = 0; nodeLen < myNode.getLength(); nodeLen++) {
				 
				Node nodeValue = myNode.item(nodeLen);
	 
				if (nodeValue.getNodeType() == Node.ELEMENT_NODE) {
		 
					Element myElement = (Element) nodeValue;
		 
					url = myElement.getElementsByTagName("url").item(0).getTextContent();
					myBrowser = myElement.getElementsByTagName("browser").item(0).getTextContent();
					userName = myElement.getElementsByTagName("userName").item(0).getTextContent();
					password = myElement.getElementsByTagName("password").item(0).getTextContent();
					System.out.println("Url is: " +url+", Browser is "+myBrowser+", UserName is "+userName+", Password is "+password);
					
				}
			}
		
			if (myBrowser.toUpperCase().equals("IE")){
				File iFile = new File("src\\main\\resources\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver", iFile.getAbsolutePath());
				myDriver = new InternetExplorerDriver();
				myDriver.get(url);
			} 	else if (myBrowser.toUpperCase().equals("FF")) {
				myDriver = new FirefoxDriver();
				myDriver.get(url);			
			} 	else if (myBrowser.toUpperCase().equals("GC")) {
				myDriver = new ChromeDriver();
				myDriver.get(url);
			} else {
				System.out.println("Incorrect Browser name :"+myBrowser);
				System.out.println("Browser name should be IE or FF or GC");
				System.out.println("Exiting Test ..");
				System.exit(0);
				
			}
			waitToPageLoad(10,By.id("brand-logo"));
			
			
		} catch (Exception exp) {
			exp.printStackTrace();
	    }
		
	}
	
	 public static void LoginUser() {
	 	 //WebDriver driver = new WebDriver();
	      Actions myAction = new Actions(myDriver);
	 	 WebElement MyElement = myDriver.findElement(By.xpath(".//*[text() = 'My Account']"));
	 	 myAction.moveToElement(MyElement).click().build().perform();
	 	 waitToPageLoad(30,By.id("login-email"));
//	 	 myDriver.findElement(By.id("login-email")).sendKeys(email);
//	 	 myDriver.findElement(By.id("login-password")).sendKeys(pwd);
//	 	 myDriver.findElement(By.id("btn-sign-in")).click();
	 }
	public static void waitToPageLoad(int Seconds,By identifer) {
		
		WebDriverWait wait = new WebDriverWait(myDriver, Seconds);
		wait.until(ExpectedConditions.presenceOfElementLocated(identifer));
		System.out.println();
		
	}
	public static void main(String arg[]){
		System.out.println("Test williamson application");
	}


}
