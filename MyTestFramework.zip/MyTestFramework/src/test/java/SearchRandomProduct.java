import java.util.List;

import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.pom.common.LaunchApp;
import com.pom.common.LoginPage;
import com.pom.common.ProductPage;
 
public class SearchRandomProduct  {
	
	public static WebDriver MyDriver;
	public static LaunchApp myWebDriver;
	public static String prdName;
	public static WebDriverWait wait;
	
	@BeforeClass
	public void TestLaunch(){
  	    LaunchApp.OpenApp();
  	    LaunchApp.LoginUser();
  	    LoginPage.userLogin();
		//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='member-greeting']/a")));
	}
	@Test
	public void searchMyProduct(){
		String myProduct = ProductPage.SearchProduct("table");
		Assert.assertEquals("table", myProduct);
	}
	@Test(dependsOnMethods="searchMyProduct")
	public void clickOnSearchProduct(){
		List<String>searchPrdName = ProductPage.clickOnSearchProductImg(1);
		System.out.println("my list size is "+searchPrdName.size());
		System.out.println("expPrdName "+searchPrdName.get(0));
		System.out.println("expPrice "+searchPrdName.get(1));
		String expPrdName = searchPrdName.get(0);
		String expPrice = searchPrdName.get(1); 
		System.out.println("Search Prd name is "+searchPrdName);
		wait = new WebDriverWait(myWebDriver.myDriver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@class='quicklook-link']")));
		myWebDriver.myDriver.findElement(By.xpath(".//*[@class='quicklook-link']")).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("overlay-content")));
		WebElement MyElement = myWebDriver.myDriver.findElement(By.id("overlay-content"));
		if (MyElement.isDisplayed()){
			System.out.println("Overlay Content Displayed - Passed");
			String actHeader = myWebDriver.myDriver.findElement(By.xpath(".//*[@id='purchasing-container']//*[@itemprop='name']")).getText();
			String actPrice = myWebDriver.myDriver.findElement(By.xpath(".//*[@id='itemselection']//*[@itemprop='price']")).getText();
			Assert.assertEquals("Product Name validation",expPrdName, actHeader);
			Assert.assertEquals("Product price validation",expPrice, actPrice);	
		}else {
			System.out.println("Overlay Content NOT Displayed - Failed");
		}
		myWebDriver.myDriver.findElement(By.xpath(".//*[@id='quicklookOverlay']/a")).click();
	}
	@AfterClass
	public void signOff(){
		//removeItem();
		LoginPage.singnOffButton(myWebDriver.myDriver).click();
		myWebDriver.myDriver.close();
	}
}
