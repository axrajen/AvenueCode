import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.pom.common.LaunchApp;
import com.pom.common.LoginPage;
import com.pom.common.ProductPage;
public class AddProdToCart  {
	public static WebDriver MyDriver;
	public static LaunchApp myWebDriver;
	public static String prdName;
	public static WebDriverWait wait;
	
	@BeforeClass
	public void TestLaunch(){
  	    LaunchApp.OpenApp();
  	    LaunchApp.LoginUser();
  	    LoginPage.userLogin();
  	    removeItem();
		//wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//*[@id='member-greeting']/a")));
	}
	@Test
	public void SelectProduct(){
		System.out.println("Im in");
		selectAndAddProduct("Cookware", "Cookware Sets");
	}
	@Test(dependsOnMethods="SelectProduct")
	public void AddProduct(){
		ProductPage.AddShipCart();
		wait = new WebDriverWait(myWebDriver.myDriver, 30);
		if (myWebDriver.myDriver.getPageSource().contains("Shopping Cart")){
			System.out.println("Navigated to Shopping Cart page");
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id("title-lineid-1")));
			String addedPrd = myWebDriver.myDriver.findElement(By.id("title-lineid-1")).getText();
			System.out.println("Added Product Name is "+addedPrd);	
		   Assert.assertEquals(prdName, addedPrd);
		} else{
			System.out.println("Not Navigated to Shopping Cart page");
		}
		validateProdQtyInShopCart();
    }

	@Test(dependsOnMethods="AddProduct")
	public void AddSameProduct(){
		SelectProduct();
		AddProduct();
		validateProdQtyInShopCart();
	
	}
	@Test(dependsOnMethods="AddSameProduct")
	public void AddDiffProduct(){
		selectAndAddProduct("Electrics", "Juicers");
		ProductPage.AddShipCart();
		validateProdQtyInShopCart();
	}
	//@Test(dependsOnMethods="AddDiffProduct")
	public void removeItem(){
		//wait = new WebDriverWait(myWebDriver.myDriver, 30);
		//List<WebElement> myRemoveLink = new ArrayList();
		int myRemoveLinkCnt = myWebDriver.myDriver.findElements(By.linkText("Remove Item")).size();
		for (int i=0;i<myRemoveLinkCnt;i++){
		  myWebDriver.myDriver.findElement(By.linkText("Remove Item")).click();
		if (myWebDriver.myDriver.getPageSource().contains("Your Shopping Cart is Currently Empty")){
			System.out.println("Shopping Cart is empty");
		} else {
			System.out.println("Shopping Cart is NOT empty");
		}
		}
	}
	@AfterClass
	public void signOff(){
		removeItem();
		LoginPage.singnOffButton(myWebDriver.myDriver).click();
		myWebDriver.myDriver.close();
	}
	
    public static void validateProdQtyInShopCart(){
		//	int myProductListSize = ProductPage.MyProductQuantity(myWebDriver.myDriver).size();
    	    myWebDriver.myDriver.findElement(By.className("view-cart")).click();
			List<WebElement> myQty = ProductPage.MyProductQuantity(myWebDriver.myDriver);
			for (int i=0;i<myQty.size();i++){
				String prdQty = myQty.get(i).getText();
				if (prdQty.equals("0")){
					System.err.println("Validation failed");
				}else {
					System.err.println("Validation Passed");
				}
	   }	
	}
    
	public void selectAndAddProduct(String MainNav, String SubNav){
		ProductPage.NavigateToProdPage(MainNav, SubNav);
		prdName = ProductPage.clickResultProduct(1);
		System.out.println("product name is "+prdName);
		String navToPrd = myWebDriver.myDriver.findElement(By.xpath(".//*[@id='pip']/div[1]/div[7]/div[2]/div[2]/h1")).getText();
		Assert.assertEquals(prdName, navToPrd, "Navigated to Correct product page");
	}
}
