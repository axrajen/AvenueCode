This framework is developed using Selenium WebDriver, Java, TestNG and Maven to support multiple browser

Input file should be in below xml format and to be placed in  C:\Users\<Name>\workspace\MyTestFramework\src\main\resources\Config.xml

Update the UserName and password details in Config.xml file before proceeding.
Upate the browser to IE or GC incase if u need to execute the test cases in IE or GC.

<?xml version="1.0" encoding="UTF-8"?>
<environment>
	<url>https://secure.williams-sonoma.com/</url>
	<browser>ff</browser>
	<userName>axrajen@gmail.com</userName>
	<password>*******</password>
</environment>

**Tested the test cases in FF alone due to time constraint.
